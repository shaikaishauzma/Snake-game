import { useState, useEffect, useCallback, useRef } from 'react';
import { playEatSound, playBonusSound, playCrashSound } from '../lib/sounds';

// Grid size and cell size
const GRID_SIZE = 20;

type Point = { x: number; y: number };

type Food = Point & {
  type: 'normal' | 'bonus';
  points: number;
};

type Particle = {
  id: number;
  x: number;
  y: number;
  dx: number;
  dy: number;
  life: number;
  maxLife: number;
  color: string;
};

const INITIAL_SNAKE = [
  { x: 10, y: 10 },
  { x: 10, y: 11 },
  { x: 10, y: 12 },
];
const INITIAL_DIRECTION = { x: 0, y: -1 };

export default function SnakeGame() {
  const [snake, setSnake] = useState<Point[]>(INITIAL_SNAKE);
  const [direction, setDirection] = useState<Point>(INITIAL_DIRECTION);
  const [food, setFood] = useState<Food>({ x: 5, y: 5, type: 'normal', points: 10 });
  const [particles, setParticles] = useState<Particle[]>([]);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(true);
  const [isShaking, setIsShaking] = useState(false);
  
  // Ref for local storage init
  useEffect(() => {
    const saved = localStorage.getItem('snakeHighScore');
    if (saved) setHighScore(parseInt(saved, 10));
  }, []);

  // Use a ref to track the last committed direction to prevent rapid self-collision before state updates
  const lastDirectionRef = useRef<Point>(INITIAL_DIRECTION);

  const generateFood = useCallback((currentSnake: Point[]): Food => {
    let newFood: Point;
    let isOccupied = true;
    while (isOccupied) {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
      isOccupied = currentSnake.some(
        (segment) => segment.x === newFood.x && segment.y === newFood.y
      );
    }
    
    const isBonus = Math.random() < 0.2; // 20% chance for bonus food
    return {
      ...newFood!,
      type: isBonus ? 'bonus' : 'normal',
      points: isBonus ? 50 : 10
    };
  }, []);

  const spawnParticles = (x: number, y: number, color: string) => {
    const newParticles: Particle[] = Array.from({ length: 8 }).map(() => ({
      id: Math.random(),
      x: x * (400 / GRID_SIZE) + (400 / GRID_SIZE / 2),
      y: y * (400 / GRID_SIZE) + (400 / GRID_SIZE / 2),
      dx: (Math.random() - 0.5) * 8,
      dy: (Math.random() - 0.5) * 8,
      life: 1,
      maxLife: 20 + Math.random() * 10,
      color,
    }));
    setParticles(prev => [...prev, ...newParticles]);
  };

  // Particle animation loop
  useEffect(() => {
    if (particles.length === 0) return;
    let animationFrameId: number;

    const animate = () => {
      setParticles(prevParticles => 
        prevParticles
          .map(p => ({
            ...p,
            x: p.x + p.dx,
            y: p.y + p.dy,
            life: p.life + 1
          }))
          .filter(p => p.life < p.maxLife)
      );
      animationFrameId = requestAnimationFrame(animate);
    };

    animationFrameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrameId);
  }, [particles.length]);

  const resetGame = () => {
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem('snakeHighScore', score.toString());
    }
    setSnake(INITIAL_SNAKE);
    setDirection(INITIAL_DIRECTION);
    lastDirectionRef.current = INITIAL_DIRECTION;
    setScore(0);
    setGameOver(false);
    setIsPaused(false);
    setParticles([]);
    setIsShaking(false);
    setFood(generateFood(INITIAL_SNAKE));
  };

  const handleDeath = () => {
    playCrashSound();
    setGameOver(true);
    setIsShaking(true);
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem('snakeHighScore', score.toString());
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === ' ' && gameOver) {
        resetGame();
        return;
      }

      if (e.key === ' ' && !gameOver) {
        setIsPaused(p => !p);
        return;
      }

      if (isPaused || gameOver) return;

      const currentDir = lastDirectionRef.current;

      switch (e.key) {
        case 'ArrowUp':
          if (currentDir.y !== 1) setDirection({ x: 0, y: -1 });
          break;
        case 'ArrowDown':
          if (currentDir.y !== -1) setDirection({ x: 0, y: 1 });
          break;
        case 'ArrowLeft':
          if (currentDir.x !== 1) setDirection({ x: -1, y: 0 });
          break;
        case 'ArrowRight':
          if (currentDir.x !== -1) setDirection({ x: 1, y: 0 });
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameOver, isPaused, generateFood, score, highScore]);

  useEffect(() => {
    if (gameOver || isPaused) return;

    const moveSnake = () => {
      setSnake((prevSnake) => {
        const head = prevSnake[0];
        const newHead = {
          x: head.x + direction.x,
          y: head.y + direction.y,
        };

        lastDirectionRef.current = direction; // Commit the direction

        // Check walls
        if (
          newHead.x < 0 ||
          newHead.x >= GRID_SIZE ||
          newHead.y < 0 ||
          newHead.y >= GRID_SIZE
        ) {
          handleDeath();
          return prevSnake;
        }

        // Check self-collision
        if (prevSnake.some((segment) => segment.x === newHead.x && segment.y === newHead.y)) {
          handleDeath();
          return prevSnake;
        }

        const newSnake = [newHead, ...prevSnake];

        // Check food collision
        if (newHead.x === food.x && newHead.y === food.y) {
          if (food.type === 'bonus') {
            playBonusSound();
            spawnParticles(food.x, food.y, '#facc15'); // Yellow particles
            setScore((s) => s + food.points);
            // Optionally remove an extra tail segment for a speed/size tradeoff
            if (newSnake.length > 3) newSnake.pop(); 
          } else {
            playEatSound();
            spawnParticles(food.x, food.y, '#ec4899'); // Pink particles
            setScore((s) => s + food.points);
          }
          setFood(generateFood(newSnake));
        } else {
          newSnake.pop(); // Remove tail
        }

        return newSnake;
      });
    };

    // calculate speed limit
    const speed = Math.max(50, 150 - Math.floor(score / 40) * 10); 
    const interval = setInterval(moveSnake, speed);
    return () => clearInterval(interval);
  }, [direction, food, gameOver, isPaused, score, generateFood]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full relative group">
      {/* HUD Info (Absolute in Bento style) */}
      <div className="hidden sm:flex absolute bottom-6 left-6 gap-4 z-20 pointer-events-none">
        <div className="bg-black/60 backdrop-blur-md px-6 py-3 rounded-2xl border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.1)]">
          <p className="text-[10px] text-cyan-400 uppercase font-bold mb-1">Current Score</p>
          <p className="text-3xl font-mono leading-none text-white">{score.toString().padStart(5, '0')}</p>
        </div>
        <div className="bg-black/60 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10">
          <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">High Score</p>
          <p className="text-3xl font-mono leading-none text-pink-500">{highScore.toString().padStart(5, '0')}</p>
        </div>
      </div>
      
      {/* Small Screen HUD */}
      <div className="sm:hidden absolute top-4 left-0 w-full flex justify-between px-4 z-20 pointer-events-none">
         <span className="text-cyan-400 font-mono text-xl">{score.toString().padStart(4, '0')}</span>
         <span className="text-pink-500 font-mono text-xl">{highScore.toString().padStart(4, '0')}</span>
      </div>

      {/* Game Board (Bento styled inner grid) */}
      <div 
        className={`relative border border-white/5 bg-black/40 rounded-lg shadow-xl overflow-hidden transition-transform ${isShaking ? 'animate-[shake_0.4s_ease-in-out]' : ''}`}
        style={{
          width: 'min(100%, 480px)',
          aspectRatio: '1/1',
        }}
      >
        {/* CSS grid for blocks */}
        <div 
          className="absolute inset-0 grid p-0.5"
          style={{
            gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
            gridTemplateRows: `repeat(${GRID_SIZE}, 1fr)`,
          }}
        >
          {/* Food */}
          <div
            className={`rounded-full ${
              food.type === 'bonus' 
                ? 'bg-yellow-400 shadow-[0_0_15px_#facc15] animate-pulse' 
                : 'bg-pink-500 shadow-[0_0_15px_#ec4899]'
            }`}
            style={{
              gridColumnStart: food.x + 1,
              gridRowStart: food.y + 1,
              transform: food.type === 'bonus' ? 'scale(0.85)' : 'scale(0.7)',
            }}
          />

          {/* Snake */}
          {snake.map((segment, index) => {
            const isHead = index === 0;
            return (
              <div
                key={`${segment.x}-${segment.y}-${index}`}
                className={`${
                  isHead ? 'bg-cyan-400 z-10' : 'bg-cyan-500/80'
                } rounded-sm transition-all duration-75`}
                style={{
                  gridColumnStart: segment.x + 1,
                  gridRowStart: segment.y + 1,
                  opacity: isHead ? 1 : Math.max(0.2, 1 - (index * 0.05)),
                  transform: isHead ? 'scale(0.95)' : 'scale(0.85)',
                  boxShadow: isHead ? '0 0 10px rgba(34,211,238,0.5)' : 'none'
                }}
              />
            );
          })}
        </div>

        {/* Particles Canvas Overlay */}
        {particles.length > 0 && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {particles.map(p => (
              <div
                key={p.id}
                className="absolute rounded-full"
                style={{
                  left: `${(p.x / 400) * 100}%`,
                  top: `${(p.y / 400) * 100}%`,
                  width: '4px',
                  height: '4px',
                  backgroundColor: p.color,
                  boxShadow: `0 0 8px ${p.color}`,
                  opacity: 1 - (p.life / p.maxLife),
                  transform: `translate(-50%, -50%)`,
                }}
              />
            ))}
          </div>
        )}

        {/* Overlays */}
        {(gameOver || isPaused) && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-30">
            {gameOver ? (
              <div className="text-center w-full animate-in fade-in zoom-in duration-300 px-4">
                <h2 className="text-red-500 font-black text-4xl sm:text-5xl mb-2 font-sans tracking-tight">
                  SYSTEM FAILURE
                </h2>
                <div className="text-slate-300 font-mono text-sm sm:text-base mb-6">
                  SEQUENCE TERMINATED AT <span className="text-white font-bold">{score}</span>
                </div>
                <button 
                  onClick={resetGame}
                  className="px-6 py-2 bg-white/10 border border-red-500/50 text-red-100 font-bold uppercase tracking-widest hover:bg-red-500 hover:text-black transition-all rounded-full"
                >
                  Reboot (Space)
                </button>
              </div>
            ) : (
              <div className="text-center w-full px-4">
                <p className="text-white/40 font-mono text-sm tracking-[0.5em] uppercase sm:tracking-[1em]">Game Paused</p>
                <p className="text-white/20 text-xs mt-3">Press [SPACE] to Resume</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

