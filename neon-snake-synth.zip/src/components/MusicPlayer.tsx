import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Volume1 } from 'lucide-react';

const TRACKS = [
  {
    id: 1,
    title: "Cybernetic Horizon (AI Generated)",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    duration: "6:12"
  },
  {
    id: 2,
    title: "Neon Overdrive (AI Generated)",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    duration: "7:05"
  },
  {
    id: 3,
    title: "Digital Mirage (AI Generated)",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    duration: "5:44"
  }
];

const formatTime = (seconds: number) => {
  if (isNaN(seconds)) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

export default function MusicPlayer() {
  const [currentTrack, setCurrentTrack] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioError, setAudioError] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.5);
  const [isMuted, setIsMuted] = useState(false);
  
  // Create an array of random seed values for the visualizer to keep it consistent-ish but animated
  const [visValues, setVisValues] = useState<number[]>(Array.from({ length: 24 }).map(() => Math.random()));

  // We use normal state for audio to manage the element
  const [audio] = useState(new Audio(TRACKS[0].url));

  useEffect(() => {
    audio.volume = isMuted ? 0 : volume;
  }, [audio, volume, isMuted]);

  useEffect(() => {
    // When track changes, update source and play if it was playing
    audio.src = TRACKS[currentTrack].url;
    audio.load();
    setAudioError(false);
    
    if (isPlaying) {
      audio.play().catch(() => setAudioError(true));
    }

    const handleEnded = () => handleNext();
    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      setProgress((audio.currentTime / (audio.duration || 1)) * 100);
      if (isPlaying) {
         setVisValues(Array.from({ length: 24 }).map(() => Math.random()));
      }
    };
    const handleLoadedMetadata = () => {
      setDuration(audio.duration);
    };

    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    
    return () => {
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [currentTrack, audio, isPlaying]); // Removed isPlaying from dep if we don't want to re-bind, but we need it for play condition

  const togglePlay = useCallback(() => {
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play()
        .then(() => {
          setIsPlaying(true);
          setAudioError(false);
        })
        .catch((e) => {
          console.error("Playback failed", e);
          setAudioError(true);
          setIsPlaying(false);
        });
    }
  }, [audio, isPlaying]);

  const handleNext = useCallback(() => {
    setCurrentTrack((prev) => (prev + 1) % TRACKS.length);
  }, []);

  const handlePrev = useCallback(() => {
    setCurrentTrack((prev) => (prev - 1 + TRACKS.length) % TRACKS.length);
  }, []);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = (parseFloat(e.target.value) / 100) * (audio.duration || 0);
    audio.currentTime = time;
    setProgress(parseFloat(e.target.value));
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
  };

  return (
    <div className="w-full h-full flex flex-col justify-between relative z-10 space-y-4">
      {/* Header Info */}
      <div className="flex justify-between items-start">
        <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-cyan-500 rounded-xl shadow-[0_8px_20px_-5px_rgba(6,182,212,0.5)] flex items-center justify-center shrink-0">
          <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
        </div>
        <div className="text-right flex-grow pl-4 min-w-0">
          <h2 className="text-white font-bold text-lg truncate w-full" title={TRACKS[currentTrack].title}>{TRACKS[currentTrack].title}</h2>
          <p className="text-xs text-slate-400 uppercase tracking-widest mt-1 truncate">AI Generated</p>
        </div>
      </div>

      <div className="space-y-6 flex-grow flex flex-col justify-end">
        {/* Waveform Visualization */}
        <div className="flex items-end gap-[3px] h-12 justify-center pb-2">
          {visValues.map((val, i) => (
             <div 
               key={i}
               className={`w-1 rounded-full transition-all duration-150 ${isPlaying ? 'bg-cyan-400/80 shadow-[0_0_8px_rgba(34,211,238,0.6)]' : 'bg-white/20'}`}
               style={{ height: isPlaying ? `${Math.max(15, val * 100)}%` : '20%' }}
             />
          ))}
        </div>

        {/* Progress Tracker */}
        <div className="w-full relative px-1">
          <div className="flex justify-between items-end mb-2 text-[10px] text-slate-500 font-mono">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={progress} 
            onChange={handleSeek}
            className="absolute -bottom-1.5 left-0 w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-cyan-400 focus:outline-none z-20"
          />
          <div className="h-1 bg-white/5 rounded-full absolute bottom-[-5px] left-0 right-0 pointer-events-none overflow-hidden">
             <div className="h-full bg-cyan-400 shadow-[0_0_10px_#22d3ee] rounded-full" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
        
        {audioError && (
          <p className="text-red-400 text-[10px] text-center font-mono uppercase tracking-widest mt-0">Network/Playback Error</p>
        )}

        {/* Controls Base */}
        <div className="flex justify-between items-center px-2">
           {/* Volume Controls */}
           <div className="flex items-center gap-2 group w-24">
             <button onClick={() => setIsMuted(!isMuted)} className="text-slate-400 hover:text-white transition-colors shrink-0">
               {isMuted || volume === 0 ? <VolumeX size={16} /> : volume < 0.5 ? <Volume1 size={16} /> : <Volume2 size={16} />}
             </button>
             <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.01"
                value={isMuted ? 0 : volume} 
                onChange={handleVolumeChange}
                className="w-16 h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-slate-300 opacity-50 group-hover:opacity-100 transition-opacity"
              />
           </div>

           {/* Media Controls */}
           <div className="flex justify-center items-center gap-6">
             <button onClick={handlePrev} className="text-slate-400 hover:text-white transition-colors">
               <SkipBack size={20} />
             </button>
             <button 
               onClick={togglePlay} 
               className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 transition-transform"
             >
               {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} className="ml-1" fill="currentColor" />}
             </button>
             <button onClick={handleNext} className="text-slate-400 hover:text-white transition-colors">
               <SkipForward size={20} />
             </button>
           </div>
           
           <div className="w-24"></div> {/* Spacer for centering media controls */}
        </div>
      </div>
    </div>
  );
}
