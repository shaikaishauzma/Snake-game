export const playAudioBeep = (freq: number, type: OscillatorType, duration: number, vol: number = 0.1) => {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.type = type;
    oscillator.frequency.setValueAtTime(freq, audioCtx.currentTime);
    
    // envelope
    gainNode.gain.setValueAtTime(vol, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.start();
    oscillator.stop(audioCtx.currentTime + duration);
  } catch (e) {
    // Ignore errors for audio context (e.g., autoplay policies)
    console.warn("Audio play failed", e);
  }
};

export const playEatSound = () => playAudioBeep(600, 'sine', 0.1, 0.1);
export const playBonusSound = () => playAudioBeep(900, 'triangle', 0.15, 0.1);
export const playCrashSound = () => playAudioBeep(100, 'sawtooth', 0.3, 0.2);
