import SnakeGame from './components/SnakeGame';
import MusicPlayer from './components/MusicPlayer';
import { AudioWaveform } from 'lucide-react';

export default function App() {
  return (
    <div className="h-screen w-full bg-[#050505] text-slate-200 p-4 lg:p-8 font-sans flex flex-col gap-6 overflow-hidden">
      {/* Top Navigation / Status Bar */}
      <header className="flex justify-between items-center border-b border-white/10 pb-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]"></div>
          <h1 className="text-xl font-bold tracking-widest text-white uppercase flex items-center gap-2">
            SynthSnake <span className="text-cyan-400">OS v1.0</span>
          </h1>
        </div>
        <div className="hidden md:flex gap-8 items-center text-xs font-mono tracking-tighter opacity-70">
          <span>CPU: 24%</span>
          <span>LATENCY: 12MS</span>
          <span className="text-cyan-400">STATUS: ONLINE</span>
          <span className="bg-white/10 px-3 py-1 rounded">SYSTEM PROTOCOL</span>
        </div>
      </header>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 lg:grid-rows-6 gap-6 flex-grow min-h-0">
        
        {/* Game Window (The Hero Card) */}
        <div className="lg:col-span-8 lg:row-span-6 bg-slate-950 rounded-3xl border-2 border-cyan-500/30 relative flex flex-col items-center justify-center overflow-hidden shadow-[inset_0_0_50px_rgba(6,182,212,0.1)] p-4">
          {/* Grid Background */}
          <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#22d3ee 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
          
          <div className="relative z-10 w-full h-full flex items-center justify-center">
            <SnakeGame />
          </div>
        </div>

        {/* Music Player Card */}
        <div className="lg:col-span-4 lg:row-span-3 bg-slate-900/50 rounded-3xl border border-white/10 p-6 flex flex-col justify-between backdrop-blur-sm relative overflow-hidden">
          <MusicPlayer />
        </div>

        {/* Protocol / Playlist Card */}
        <div className="lg:col-span-4 lg:row-span-3 bg-slate-900/50 rounded-3xl border border-white/10 p-6 backdrop-blur-sm flex flex-col">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">System Protocol</h3>
          <div className="space-y-2 overflow-y-auto flex-grow custom-scrollbar">
            <div className="flex items-center gap-4 p-3 rounded-2xl bg-cyan-400/10 border border-cyan-400/20">
              <span className="text-[10px] font-mono text-cyan-400">01</span>
              <div className="flex-grow">
                <p className="text-sm font-semibold text-white">Navigation Override</p>
                <p className="text-[10px] text-slate-400 uppercase">Arrow Keys / Directional Input</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 p-3 rounded-2xl hover:bg-white/5 border border-transparent transition-colors">
              <span className="text-[10px] font-mono text-slate-600">02</span>
              <div className="flex-grow">
                <p className="text-sm font-semibold text-slate-300">Execution Halts</p>
                <p className="text-[10px] text-slate-500 uppercase">[SPACEBAR] Pause or Resume</p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-3 rounded-2xl hover:bg-white/5 border border-transparent transition-colors">
              <span className="text-[10px] font-mono text-slate-600">03</span>
              <div className="flex-grow">
                <p className="text-sm font-semibold text-slate-300">Data Acquisition</p>
                <p className="text-[10px] text-slate-500 uppercase">Avoid Walls & Self-Intersection</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-3 rounded-2xl hover:bg-white/5 border border-transparent transition-colors">
              <span className="text-[10px] font-mono text-slate-600">04</span>
              <div className="flex-grow">
                <p className="text-sm font-semibold text-slate-300">Aesthetic Nodes</p>
                <p className="text-[10px] text-slate-500 uppercase">Yellow Packets Yield Bonus</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Controls */}
      <footer className="hidden md:flex justify-between items-center bg-white/5 border border-white/10 rounded-2xl px-6 py-4 shrink-0">
        <div className="flex gap-6 text-[10px] font-bold uppercase tracking-widest flex-wrap">
          <span className="text-white/40">Movement: <span className="text-white">ARROW KEYS</span></span>
          <span className="text-white/40">Pause/Start: <span className="text-white">SPACE</span></span>
          <span className="text-white/40">Audio Track: <span className="text-white">INCLUDED AI</span></span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-[10px] font-mono text-green-500">SYSTEM OPTIMAL</span>
        </div>
      </footer>
    </div>
  );
}
