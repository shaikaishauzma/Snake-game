import React from 'react';
import { motion } from 'motion/react';
import MusicPlayer from './components/MusicPlayer';
import SnakeGame from './components/SnakeGame';

export default function App() {
  return (
    <div className="h-screen w-full bg-[#030305] text-slate-100 flex flex-col relative overflow-hidden">
      {/* Cinematic Animated Background Blobs */}
      <div className="synth-grid-container">
        <div className="synth-grid"></div>
      </div>
      <motion.div 
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
          x: [0, 50, 0],
          y: [0, 20, 0]
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        className="atmosphere-blob bg-cyan-600/30 w-[600px] h-[600px] top-[-150px] left-[-150px]"
      />
      <motion.div 
        animate={{ 
          scale: [1, 1.3, 1],
          opacity: [0.2, 0.4, 0.2],
          x: [0, -40, 0],
          y: [0, -40, 0]
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        className="atmosphere-blob bg-pink-700/20 w-[500px] h-[500px] bottom-[-100px] right-[-100px]"
      />
      
      {/* Top Navigation / Header */}
      <motion.header 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="h-16 flex items-center justify-between px-6 sm:px-10 z-20 shrink-0 w-full glass-panel border-b-0 border-t-0 border-l-0 border-r-0 border-white/5"
      >
        <div className="flex items-center space-x-4">
          <motion.div 
            whileHover={{ rotate: 180 }}
            transition={{ duration: 0.5 }}
            className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-indigo-600 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.5)]"
          >
            <div className="w-4 h-4 rounded-full border-2 border-white"></div>
          </motion.div>
          <span className="font-serif tracking-tight text-2xl bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
            NEON SLITHER
          </span>
        </div>
        <div className="hidden sm:flex items-center space-x-8">
          <div className="text-right">
            <div className="text-[9px] text-cyan-400 uppercase tracking-[0.3em] font-semibold opacity-80">ENV</div>
            <div className="text-xs font-mono tracking-widest mt-1 opacity-90">PROD_v3</div>
          </div>
          <div className="h-6 w-px bg-white/10"></div>
          <div className="text-right">
            <div className="text-[9px] text-pink-400 uppercase tracking-[0.3em] font-semibold opacity-80">LATENCY</div>
            <div className="text-xs font-mono tracking-widest mt-1 opacity-90"><span className="animate-pulse">12ms</span></div>
          </div>
        </div>
      </motion.header>
      
      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-[1400px] mx-auto flex flex-col lg:flex-row p-4 sm:p-8 gap-8 z-10 h-[calc(100vh-64px)] overflow-hidden">
        
        {/* Left Sidebar: Controls & Audio */}
        <motion.aside 
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="w-full lg:w-[360px] flex flex-col shrink-0 h-full"
        >
          <div className="glass-panel rounded-[32px] p-6 shadow-2xl h-full flex flex-col overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-b from-white/[0.02] to-transparent pointer-events-none"></div>
            <MusicPlayer />
          </div>
        </motion.aside>

        {/* Center: Game Window */}
        <motion.section 
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          className="flex-1 flex items-center justify-center relative min-h-[400px]"
        >
          {/* Decorative frame */}
          <div className="absolute inset-0 glass-panel rounded-[32px] pointer-events-none z-0"></div>
          <div className="relative z-10 w-full h-full p-4 sm:p-8 flex items-center justify-center">
            <SnakeGame />
          </div>
        </motion.section>
        
      </main>
      <div className="noise-overlay"></div>
      <div className="scanlines"></div>
    </div>
  );
}
