import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const GRID_SIZE = 20;
const INITIAL_SNAKE = [
  { x: 10, y: 10 },
  { x: 10, y: 11 },
  { x: 10, y: 12 },
];
const INITIAL_DIRECTION = { x: 0, y: -1 };
const INITIAL_SPEED = 150;

type Point = { x: number; y: number };

export default function SnakeGame() {
  const [snake, setSnake] = useState<Point[]>(INITIAL_SNAKE);
  const [direction, setDirection] = useState<Point>(INITIAL_DIRECTION);
  const [food, setFood] = useState<Point>({ x: 5, y: 5 });
  const [specialFood, setSpecialFood] = useState<Point | null>(null);
  const [particles, setParticles] = useState<{id: number, x: number, y: number, color: string}[]>([]);
  
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('neon_snake_highscore') || '0', 10);
  });
  const [speed, setSpeed] = useState<number>(INITIAL_SPEED);
  const [foodEaten, setFoodEaten] = useState<number>(0);
  const [combo, setCombo] = useState<number>(0); // Streak combo
  const [showCombo, setShowCombo] = useState<boolean>(false);
  
  const scoreRef = useRef(score);
  const directionRef = useRef(direction);

  useEffect(() => {
    scoreRef.current = score;
    directionRef.current = direction;
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem('neon_snake_highscore', score.toString());
    }
  }, [score, direction, highScore]);

  // Audio synthesis for immersive retro feel
  const playSound = useCallback((freq = 440, type: OscillatorType = 'sine', duration = 0.1, vol = 0.1) => {
    try {
      const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextCtor) return;
      
      const audioCtx = new AudioContextCtor();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(freq, audioCtx.currentTime);
      if (type === 'square') {
         oscillator.frequency.exponentialRampToValueAtTime(freq * 1.5, audioCtx.currentTime + duration);
      } else if (type === 'sawtooth') {
         oscillator.frequency.exponentialRampToValueAtTime(freq * 0.5, audioCtx.currentTime + duration);
      }
      
      gainNode.gain.setValueAtTime(vol, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + duration);
    } catch(e) {
      // Audio context might fail on initial load without interaction
    }
  }, []);

  const generateFood = useCallback((currentSnake: Point[], excludeFood?: Point | null) => {
    let newFood: Point;
    while (true) {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
      // eslint-disable-next-line no-loop-func
      const inSnake = currentSnake.some((segment) => segment.x === newFood.x && segment.y === newFood.y);
      const isExclude = excludeFood && newFood.x === excludeFood.x && newFood.y === excludeFood.y;
      if (!inSnake && !isExclude) break;
    }
    return newFood;
  }, []);

  const resetGame = () => {
    setSnake(INITIAL_SNAKE);
    setDirection(INITIAL_DIRECTION);
    setScore(0);
    setSpeed(INITIAL_SPEED);
    setFoodEaten(0);
    setCombo(0);
    setSpecialFood(null);
    setGameOver(false);
    setIsPaused(false);
    setFood(generateFood(INITIAL_SNAKE));
    setParticles([]);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent scrolling
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === ' ' || e.key === 'Escape') {
        setIsPaused(prev => !prev);
        return;
      }

      const currentDir = directionRef.current;
      if (gameOver || isPaused) return;

      switch (e.key) {
        case 'ArrowUp':
        case 'w':
          if (currentDir.y !== 1) setDirection({ x: 0, y: -1 });
          break;
        case 'ArrowDown':
        case 's':
          if (currentDir.y !== -1) setDirection({ x: 0, y: 1 });
          break;
        case 'ArrowLeft':
        case 'a':
          if (currentDir.x !== 1) setDirection({ x: -1, y: 0 });
          break;
        case 'ArrowRight':
        case 'd':
          if (currentDir.x !== -1) setDirection({ x: 1, y: 0 });
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameOver, isPaused]);

  // Particle helper
  const triggerParticles = useCallback((x: number, y: number, color: string) => {
    const pid = Date.now() + Math.random();
    setParticles(p => [...p, { id: pid, x, y, color }]);
    setTimeout(() => {
      setParticles(p => p.filter(part => part.id !== pid));
    }, 600);
  }, []);

  // Combo display effect
  const triggerComboDisplay = useCallback(() => {
    setShowCombo(true);
    setTimeout(() => setShowCombo(false), 1500);
  }, []);

  useEffect(() => {
    if (gameOver || isPaused) return;

    const moveSnake = () => {
      setSnake((prevSnake) => {
        const head = prevSnake[0];
        const newHead = {
          x: head.x + direction.x,
          y: head.y + direction.y,
        };

        // Wall collision
        if (
          newHead.x < 0 ||
          newHead.x >= GRID_SIZE ||
          newHead.y < 0 ||
          newHead.y >= GRID_SIZE
        ) {
          setGameOver(true);
          playSound(150, 'sawtooth', 0.5, 0.2); 
          return prevSnake;
        }

        // Self collision
        if (prevSnake.some((segment) => segment.x === newHead.x && segment.y === newHead.y)) {
          setGameOver(true);
          playSound(150, 'sawtooth', 0.5, 0.2); 
          return prevSnake;
        }

        const newSnake = [newHead, ...prevSnake];
        let ateSomething = false;

        // Regular food logic
        if (newHead.x === food.x && newHead.y === food.y) {
          ateSomething = true;
          const scoreIncrease = 10 + (combo * 2);
          setScore((s) => s + scoreIncrease);
          setSpeed((s) => Math.max(s - 3, 50));
          const newFoodCount = foodEaten + 1;
          setFoodEaten(newFoodCount);
          setFood(generateFood(newSnake, specialFood));
          
          triggerParticles(food.x, food.y, '#ec4899'); // Pink particles
          playSound(600, 'square', 0.1); 

          if (newFoodCount % 3 === 0) {
            setCombo(c => {
               const newCombo = c + 1;
               if (newCombo > 1) triggerComboDisplay();
               return newCombo;
            });
          }

          // Special food spawn
          if (newFoodCount % 5 === 0 && !specialFood) {
            const sFood = generateFood(newSnake, food);
            setSpecialFood(sFood);
            playSound(800, 'sine', 0.3); // Spawn sound
            
            // Auto disappear logic
            setTimeout(() => {
              setSpecialFood(current => {
                 if (current && current.x === sFood.x && current.y === sFood.y) {
                    setCombo(0); // Missed golden apple drops combo
                    return null;
                 }
                 return current;
              });
            }, 5000);
          }
        } 
        // Special food logic
        else if (specialFood && newHead.x === specialFood.x && newHead.y === specialFood.y) {
          ateSomething = true;
          setScore((s) => s + 50 + (combo * 5));
          setSpecialFood(null);
          triggerParticles(specialFood.x, specialFood.y, '#fbbf24'); // Gold particles
          playSound(1200, 'triangle', 0.2, 0.15); 
          setCombo(c => {
             const newCombo = c + 2;
             triggerComboDisplay();
             return newCombo;
          });
        }

        if (!ateSomething) {
          newSnake.pop(); // remove tail
        }

        return newSnake;
      });
    };

    const intervalId = setInterval(moveSnake, speed);
    return () => clearInterval(intervalId);
  }, [direction, food, specialFood, gameOver, isPaused, generateFood, speed, foodEaten, combo, playSound, triggerParticles, triggerComboDisplay]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full max-w-3xl mx-auto relative">
      {/* Huge Background Typography */}
      <div className="absolute top-[-50px] right-[-50px] overflow-hidden pointer-events-none opacity-[0.02] select-none scale-150 transform transition-transform duration-1000">
        <h1 className="text-[15rem] font-black leading-none font-sans italic tracking-tighter">PLAY</h1>
      </div>

      <motion.div 
        animate={gameOver ? { x: [-15, 15, -10, 10, -5, 5, 0], y: [-10, 10, -5, 5, -2, 2, 0] } : {}}
        transition={{ duration: 0.5, ease: "easeInOut" }}
        className="relative w-full max-w-[600px] aspect-square rounded-[32px] overflow-hidden glass-panel p-2 shadow-2xl z-10"
      >
        {/* Top HUD: Score & High Score */}
        <motion.div 
          key={score}
          initial={{ scale: 1.1, textShadow: "0 0 20px #22d3ee" }}
          animate={{ scale: 1, textShadow: "0 0 0px #22d3ee" }}
          className="absolute top-6 left-6 bg-black/60 border border-white/10 px-5 py-3 rounded-2xl z-30 shadow-lg backdrop-blur-md flex items-center gap-5"
        >
          <div>
            <div className="text-cyan-400/80 text-[10px] leading-tight mb-1 uppercase tracking-[0.2em] font-bold">Curr Score</div>
            <div className="leading-none text-2xl font-mono text-white tracking-wider">{score.toString().padStart(4, '0')}</div>
          </div>
          <div className="w-px h-8 bg-white/10"></div>
          <div>
            <div className="text-yellow-400/80 text-[10px] leading-tight mb-1 uppercase tracking-[0.2em] font-bold">Best</div>
            <div className="leading-none text-2xl font-mono text-yellow-500 tracking-wider font-bold">{highScore.toString().padStart(4, '0')}</div>
          </div>
        </motion.div>
        
        {/* Right HUD: Pause Indicator */}
        <div className="absolute top-6 right-6 bg-black/40 border border-white/10 px-4 py-2 rounded-xl text-slate-400 font-mono text-xs z-30 backdrop-blur-sm shadow-lg">
          {isPaused ? <span className="text-pink-400 animate-pulse font-bold tracking-widest text-sm">PAUSED</span> : <span className="opacity-60">SPACE: PAUSE</span>}
        </div>
        
        {/* Bottom HUD: Speed */}
        <div className="absolute bottom-6 left-6 bg-black/50 border border-pink-500/30 px-5 py-3 rounded-2xl z-30 backdrop-blur-md flex flex-col shadow-[0_0_20px_rgba(236,72,153,0.15)]">
           <span className="text-[9px] text-pink-400 uppercase font-black tracking-widest leading-none mb-2">Eng. Speed</span>
           <span className="text-2xl font-mono text-white leading-none">{(200 - speed).toString()}<span className="text-[10px] text-white/50 ml-1 tracking-widest">x</span></span>
        </div>

        {/* Dynamic Combo Floating Text */}
        <AnimatePresence>
          {showCombo && combo > 0 && (
            <motion.div 
              initial={{ scale: 0.5, opacity: 0, y: 50, rotate: -10 }}
              animate={{ scale: 1.2, opacity: 1, y: 0, rotate: 0 }}
              exit={{ scale: 2, opacity: 0, y: -50 }}
              className="absolute top-[40%] left-[50%] -translate-x-1/2 -translate-y-1/2 z-40 text-center pointer-events-none"
            >
              <div className="text-5xl font-black italic text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-300 drop-shadow-[0_0_20px_rgba(250,204,21,0.5)]">
                {combo}x
              </div>
              <div className="text-lg uppercase tracking-widest text-yellow-300 font-bold mt-[-5px]">Combo!</div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* The Game Board */}
        <div 
          className="game-board w-full h-full rounded-[24px] overflow-hidden relative shadow-[inset_0_0_100px_rgba(0,0,0,0.8)]"
          style={{ 
            gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
            gridTemplateRows: `repeat(${GRID_SIZE}, 1fr)`
          }}
        >
          {/* Grid Background overlay */}
          <div className="absolute inset-0 grid pointer-events-none z-0 opacity-40 mix-blend-screen"
               style={{ 
                 gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
                 gridTemplateRows: `repeat(${GRID_SIZE}, 1fr)`
               }}
          >
            {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => (
              <div key={i} className="grid-line border-[rgba(255,255,255,0.02)] border-[0.5px]"></div>
            ))}
          </div>

          {/* Render Game Objects */}
          {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => {
            const x = i % GRID_SIZE;
            const y = Math.floor(i / GRID_SIZE);
            const isSnakeHead = snake[0].x === x && snake[0].y === y;
            const isSnakeBody = snake.some((seg) => seg.x === x && seg.y === y) && !isSnakeHead;
            const isRegFood = food.x === x && food.y === y;
            const isSpecFood = specialFood && specialFood.x === x && specialFood.y === y;
            
            const activeParticle = particles.find(p => p.x === x && p.y === y);

            const snakeIndex = snake.findIndex(seg => seg.x === x && seg.y === y);
            const intensity = snakeIndex !== -1 ? Math.max(0.2, 1 - (snakeIndex / Math.max(snake.length, 1))) : 0;

            return (
              <div key={i} className="relative w-full h-full flex items-center justify-center">
                {/* Snake Body segment */}
                {isSnakeBody && (
                  <div className="w-[85%] h-[85%] bg-cyan-400 rounded-sm z-10 transform transition-all duration-[50ms]" 
                       style={{ 
                         opacity: Math.min(1, intensity + 0.3), 
                         boxShadow: `0 0 ${20 * intensity}px #22d3ee, inset 0 0 8px rgba(255,255,255,0.9)`,
                         transform: `scale(${0.7 + (intensity * 0.3)})`
                       }} 
                  />
                )}

                {/* Snake Head */}
                {isSnakeHead && (
                  <div className="w-[110%] h-[110%] bg-white rounded shadow-[0_0_30px_#22d3ee,0_0_20px_#fff] z-25 
                                  transform transition-all duration-[50ms]" />
                )}
                
                {/* Regular Pink Food */}
                {isRegFood && (
                  <motion.div 
                    animate={{ scale: [0.8, 1.2, 0.8], boxShadow: ["0 0 15px #ec4899", "0 0 35px #ec4899, 0 0 10px #fff", "0 0 15px #ec4899"] }}
                    transition={{ duration: 1.2, repeat: Infinity }}
                    className="w-[80%] h-[80%] bg-pink-500 rounded-full z-15" 
                  />
                )}
                
                {/* Special Golden Food */}
                {isSpecFood && (
                  <motion.div 
                    animate={{ scale: [0.9, 1.4, 0.9], rotate: [0, 90, 180, 270, 360] }}
                    transition={{ duration: 0.6, repeat: Infinity, ease: "linear" }}
                    className="w-[95%] h-[95%] bg-gradient-to-br from-yellow-300 to-orange-500 rounded-sm shadow-[0_0_40px_#f59e0b,0_0_20px_#fff] z-15" 
                  />
                )}

                {/* Explosion/Eat Particles */}
                <AnimatePresence>
                  {activeParticle && (
                    <motion.div
                      key={activeParticle.id}
                      initial={{ scale: 0.2, opacity: 1, borderWidth: "4px" }}
                      animate={{ scale: 3.5, opacity: 0, borderWidth: "0px" }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                      className="absolute rounded-full border-solid z-20 pointer-events-none"
                      style={{ 
                        borderColor: activeParticle.color,
                        width: '100%',
                        height: '100%',
                        boxShadow: `0 0 30px ${activeParticle.color}, inset 0 0 20px ${activeParticle.color}`
                      }}
                    />
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

        {/* Game Over Screen */}
        <AnimatePresence>
          {gameOver && (
            <motion.div 
              initial={{ opacity: 0, backdropFilter: "blur(0px)" }}
              animate={{ opacity: 1, backdropFilter: "blur(20px)" }}
              exit={{ opacity: 0, backdropFilter: "blur(0px)" }}
              transition={{ duration: 0.4 }}
              className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-8 text-center z-50 overflow-hidden"
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(236,72,153,0.2)_0%,transparent_70%)] pointer-events-none"></div>
              
              <motion.h2 
                animate={{ textShadow: ["0 0 10px #ec4899", "0 0 40px #ec4899", "0 0 10px #ec4899"] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="text-5xl sm:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-br from-pink-500 to-rose-400 mb-6 tracking-widest uppercase italic font-sans"
              >
                Terminated
              </motion.h2>

              <div className="glass-panel border-pink-500/40 px-10 py-8 rounded-[32px] mb-10 relative overflow-hidden group shadow-[0_0_50px_rgba(236,72,153,0.15)]">
                <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.05)_50%,transparent_75%,transparent_100%)] bg-[length:250%_250%,100%_100%] animate-[shimmer_2s_infinite] pointer-events-none"></div>
                <div className="text-xs uppercase tracking-[0.4em] text-pink-400 mb-3 font-black">Final Score</div>
                <div className="font-mono text-white text-6xl tracking-wider font-light drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]">
                  {score.toString().padStart(4, '0')}
                </div>
                
                {score >= highScore && score > 0 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.5, rotate: 10 }}
                    animate={{ opacity: 1, y: 0, scale: 1, rotate: -15 }}
                    transition={{ type: "spring", bounce: 0.6, delay: 0.2 }}
                    className="absolute -top-4 -right-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-[11px] font-black uppercase tracking-widest px-4 py-2 rounded-full shadow-[0_0_25px_rgba(250,204,21,0.6)]"
                  >
                    New Best!
                  </motion.div>
                )}
              </div>

              <motion.button 
                whileHover={{ scale: 1.05, boxShadow: "0 0 40px rgba(34,211,238,0.5)" }}
                whileTap={{ scale: 0.95 }}
                onClick={resetGame}
                className="px-10 py-5 bg-cyan-400 text-black rounded-full font-black uppercase tracking-[0.2em] text-sm relative overflow-hidden group shadow-[0_0_20px_rgba(34,211,238,0.3)]"
              >
                <div className="absolute inset-0 bg-white/30 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-out skew-x-12"></div>
                Initialize Reboot
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Helper Footer Controls */}
      <div className="mt-10 flex items-center justify-center gap-10 font-mono text-[11px] text-slate-500/80 tracking-[0.2em] uppercase font-bold">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 border border-slate-600/50 rounded flex items-center justify-center text-slate-400">W</div> 
          Navigation
        </div>
        <div className="flex items-center gap-3">
          <div className="w-20 h-6 border border-slate-600/50 rounded flex items-center justify-center text-[8px] text-slate-400">SPACE</div> 
          System Pause
        </div>
      </div>
    </div>
  );
}
