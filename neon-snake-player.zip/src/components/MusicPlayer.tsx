import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Music, Disc } from 'lucide-react';

const MUSIC_TRACKS = [
  {
    id: 1,
    title: "Neon City Drift",
    artist: "AI Synthwave",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    cover: "https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&w=300&q=80",
  },
  {
    id: 2,
    title: "Cybernetic Pulse",
    artist: "AI Darksynth",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    cover: "https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?auto=format&fit=crop&w=300&q=80",
  },
  {
    id: 3,
    title: "Digital Horizon",
    artist: "AI Chillwave",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    cover: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80",
  }
];

export default function MusicPlayer() {
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentTrack = MUSIC_TRACKS[currentTrackIndex];

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio(currentTrack.url);
      
      audioRef.current.addEventListener('timeupdate', handleTimeUpdate);
      audioRef.current.addEventListener('loadedmetadata', handleLoadedMetadata);
      audioRef.current.addEventListener('ended', handleNext);
    } else {
      audioRef.current.src = currentTrack.url;
    }

    if (isPlaying) {
      audioRef.current.play().catch(e => console.error("Playback failed", e));
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.removeEventListener('timeupdate', handleTimeUpdate);
        audioRef.current.removeEventListener('loadedmetadata', handleLoadedMetadata);
        audioRef.current.removeEventListener('ended', handleNext);
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTrackIndex]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = isMuted;
    }
  }, [isMuted]);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(e => {
          console.error("Playback failed", e);
          setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress((audioRef.current.currentTime / audioRef.current.duration) * 100 || 0);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handlePlayPause = () => setIsPlaying(!isPlaying);

  const handleNext = () => {
    setCurrentTrackIndex((prev) => (prev + 1) % MUSIC_TRACKS.length);
    setIsPlaying(true);
  };

  const handlePrev = () => {
    setCurrentTrackIndex((prev) => (prev - 1 + MUSIC_TRACKS.length) % MUSIC_TRACKS.length);
    setIsPlaying(true);
  };

  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds)) return "00:00";
    const m = Math.floor(timeInSeconds / 60);
    const s = Math.floor(timeInSeconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const currentTime = audioRef.current?.currentTime || 0;

  return (
    <div className="flex flex-col h-full gap-6 w-full z-10 relative">
      {/* Current Track Info / Cover Area */}
      <div className="flex flex-col items-center mb-2 mt-4 space-y-6">
        <motion.div 
          animate={{ rotate: isPlaying ? 360 : 0 }}
          transition={{ duration: 20, ease: "linear", repeat: Infinity }}
          className="relative w-48 h-48 rounded-full p-1 border border-white/20 shadow-[0_0_30px_rgba(2ec4b6,0.15)] flex items-center justify-center bg-black/50"
        >
          <div className="absolute inset-0 rounded-full border border-pink-500/30 scale-105 pointer-events-none"></div>
          <img 
            src={currentTrack.cover} 
            alt={currentTrack.title}
            className="w-full h-full object-cover rounded-full pointer-events-none opacity-90"
          />
          {/* Vinyl center dot */}
          <div className="absolute w-4 h-4 bg-black rounded-full border border-white/20 z-10"></div>
          
          <AnimatePresence>
            {isPlaying && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-cyan-400/10 rounded-full pointer-events-none blur-md"
              ></motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        <div className="text-center w-full">
          <motion.h3 
            key={currentTrack.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-serif text-2xl font-bold tracking-tight text-white mb-1"
          >
            {currentTrack.title}
          </motion.h3>
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-cyan-400 opacity-80">
            {currentTrack.artist}
          </p>
        </div>
      </div>

      {/* Progress & Controls */}
      <div className="flex flex-col gap-4 mt-auto">
        <div className="w-full flex flex-col gap-2">
          <div className="h-1 bg-white/10 w-full rounded-full overflow-hidden relative cursor-pointer group">
            <motion.div 
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-400 to-indigo-500 rounded-full"
              style={{ width: `${progress}%` }}
              layoutId="progress"
            ></motion.div>
            {/* Glow over the progress */}
            <motion.div 
              className="absolute top-0 left-0 h-full bg-white opacity-20 blur-sm rounded-full"
              style={{ width: `${progress}%` }}
            ></motion.div>
          </div>
          <div className="flex justify-between text-[9px] font-mono tracking-widest text-slate-500 uppercase">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div className="flex items-center justify-between mt-2">
           <button 
             onClick={() => setIsMuted(!isMuted)} 
             className="text-slate-500 hover:text-white transition-colors p-2"
           >
             {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
           </button>

           <div className="flex items-center space-x-6">
             <motion.button 
               whileTap={{ scale: 0.9 }}
               onClick={handlePrev} 
               className="text-slate-400 hover:text-white"
             >
               <SkipBack className="w-6 h-6" fill="currentColor" />
             </motion.button>
             
             <motion.button 
               whileTap={{ scale: 0.9 }}
               whileHover={{ scale: 1.05 }}
               onClick={handlePlayPause} 
               className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.2)]"
             >
               {isPlaying ? 
                 <Pause className="w-6 h-6" fill="currentColor" /> : 
                 <Play className="w-6 h-6 ml-1" fill="currentColor" />
               }
             </motion.button>

             <motion.button 
               whileTap={{ scale: 0.9 }}
               onClick={handleNext} 
               className="text-slate-400 hover:text-white"
             >
               <SkipForward className="w-6 h-6" fill="currentColor" />
             </motion.button>
           </div>
           
           <div className="w-9"></div> {/* Spacer to keep play button centered */}
        </div>
      </div>

      <div className="w-full h-px bg-white/5 my-2"></div>

      {/* Playlist List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-1 min-h-[140px]">
        {MUSIC_TRACKS.map((track, idx) => {
          const isActive = currentTrackIndex === idx;
          return (
            <motion.div 
              key={track.id}
              whileHover={{ x: 4, backgroundColor: "rgba(255,255,255,0.05)" }}
              onClick={() => { setCurrentTrackIndex(idx); setIsPlaying(true); }}
              className={`p-3 rounded-xl cursor-pointer transition-colors flex items-center justify-between ${isActive ? 'bg-white/5' : ''}`}
            >
              <div className="flex items-center space-x-3 truncate">
                <div className={`w-8 h-8 rounded shrink-0 flex items-center justify-center ${isActive ? 'bg-cyan-500/20 text-cyan-400 text-xs' : 'bg-white/5 text-slate-500 text-xs font-mono'}`}>
                  {isActive && isPlaying ? <Disc className="w-4 h-4 animate-spin" /> : `0${idx + 1}`}
                </div>
                <div className="truncate">
                  <p className={`text-sm font-semibold truncate ${isActive ? 'text-white' : 'text-slate-300'}`}>{track.title}</p>
                  <p className={`text-[10px] uppercase font-mono tracking-wider ${isActive ? 'text-cyan-400' : 'text-slate-500'}`}>{track.artist}</p>
                </div>
              </div>
              
              {isActive && isPlaying && (
                <div className="flex space-x-1 items-end h-3 shrink-0 ml-2">
                  <motion.div animate={{ height: ["40%", "100%", "40%"] }} transition={{ duration: 0.8, repeat: Infinity }} className="w-1 bg-cyan-400 rounded-full"></motion.div>
                  <motion.div animate={{ height: ["60%", "30%", "100%", "60%"] }} transition={{ duration: 0.9, repeat: Infinity }} className="w-1 bg-cyan-400 rounded-full"></motion.div>
                  <motion.div animate={{ height: ["100%", "50%", "80%", "100%"] }} transition={{ duration: 1.1, repeat: Infinity }} className="w-1 bg-cyan-400 rounded-full"></motion.div>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
